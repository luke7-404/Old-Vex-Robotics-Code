/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Auton1               limit         A               
// Auton2               limit         B               
// Auton3               limit         C               
// Auton4               limit         D               
// leftFront            motor         1               
// leftBack             motor         12              
// rightFront           motor         2               
// rightBack            motor         14              
// Controller1          controller                    
// Intake               motor_group   11, 13          
// Inertial             inertial      20              
// DiskPush             digital_out   E               
// StringP1             digital_out   F               
// StringP2             digital_out   G               
// StringP3             digital_out   H               
// FlyWheel             motor         17              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

// function to move the drivetrain motors (Used for testing the auton switcher)
void driveForward() { 
  leftFront.spin(fwd);
  leftBack.spin(fwd);
  rightBack.spin(fwd);
  rightFront.spin(fwd);
}

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}


/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {

  //uses the auton number selected to run the auton, and checks if you confirmed


  if (Auton1.pressing() == 1){
    // Run First Auton Code
    Brain.Screen.clearScreen();
    Brain.Screen.printAt(2, 40, "Runing Auton 1...");
  }
  else if (Auton2.pressing() == 1) {
    // Run Second Auton Code
    Brain.Screen.clearScreen();
    Brain.Screen.printAt(2, 40, "Runing Auton 2...");
  }
    else if (Auton3.pressing() == 1) {
    // Run Third Auton Code
    Brain.Screen.clearScreen();
    Brain.Screen.printAt(2, 40, "Runing Auton 3...");
  }
    else if (Auton4.pressing() == 1) {
    // Run Forth Auton Code
    Brain.Screen.clearScreen();
    Brain.Screen.printAt(2, 40, "Runing Auton 4...");
  }
  else {
    // Run No Auton
    Brain.Screen.clearScreen();
    Brain.Screen.printAt(2, 40, "No Auton Selected!!!");
  }
}



/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {


// These lines set the controllers analog sticks to the left motors nad right motors using the tank drive layout
//This is Left Side AXES 3
    leftFront.spin(vex::directionType::fwd,Controller1.Axis3.position(vex::percentUnits::pct),vex::percentUnits::pct);
    leftBack.spin(vex::directionType::fwd,Controller1.Axis3.position(vex::percentUnits::pct),vex::percentUnits::pct);
    //This is Right Side AXES 2
    rightBack.spin(vex::directionType::rev,Controller1.Axis2.position(vex::percentUnits::pct),vex::percentUnits::pct);
    rightFront.spin(vex::directionType::rev,Controller1.Axis2.position(vex::percentUnits::pct),vex::percentUnits::pct);


////////////////////////////////////
// Controller's button assignment //
////////////////////////////////////

    /* condtional if/ if else/ else statement for the motor group to intake the disks for the fly wheel.
     When L2 is pushed the motors spin to take the disks in, when L1 is pressed it reverses the motors for 
     if there is a disk jam, and lastly the else part is to make sure if both of those actions don't 
     happen then the motors will finish rolling so that they don't heat up */
    if(Controller1.ButtonL2.pressing()){
      Intake.spin(reverse);
    }
    else if (Controller1.ButtonL1.pressing()) {
      Intake.spin(forward);
    }
    else {
      Intake.stop(coast); 
    }

    /* condtional if/ if else/ else statement for the pistion to push the disks into the fly wheel.
     When r2 is pushed the pistion pushes the disk in the fly wheel, when r1 is pressed it retracts for the
    next disk, and lastly the else part is to make sure if both of those actions don't happen then nothing will */
    if (Controller1.ButtonR2.pressing()){
      DiskPush.set(true);
    }
    else if(Controller1.ButtonR1.pressing()){
      DiskPush.set(false);
    }
    else {
      DiskPush.set(false);
    }


    /* condtional if/ else statement for when the final string pistions are fired. it 
    makes sure that the strings will only fire when x button is clicked but nothing else */
    if (Controller1.ButtonX.pressing()){
      StringP1.set(true);
      StringP2.set(true);
      StringP3.set(true);
    }
    else {
      StringP1.set(false);
      StringP2.set(false);
      StringP3.set(false);
    }


    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}



//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  
  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
